import React from "react";
import Form from "./component/Form";
import "./App.css";

const App = () => {
  return (
    <div className="container">
      <Form />
    </div>
  );
}

export default App