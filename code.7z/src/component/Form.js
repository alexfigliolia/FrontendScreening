import React, { Component } from "react";
import form from "../data/data";

class Form extends Component {

    state = {
        firstName: "",
        hasMiddleName: false,
        middleName: "",
        lastName: "",
        address1: "",
        apartmentOrSuite: false,
        address2: "",
        city: "",
        state: "",
        country: "",
        zipCode: "",
        disabledMiddleNameInput: true,
        disabledapartmentOrSuiteInput: true,
        disabledBtn: true,
        disabledSelectBox: true
    }

    constructor(props) {
        super(props);
    }

    componentDidMount() {
        // preserve the initial state in a new object
        this.baseState = this.state
    }

    render() {
        return this.rederForm()
    }

    rederForm = () => {
        const formSchema = Object.keys(form)
        return formSchema.length > 0 && <form onSubmit={this.onFormSubmitHandler}><h1>YOUR INFORMATION</h1>{this.addFieldset(formSchema)}
            <button type="submit" className="disabledBtn" disabled={this.state.disabledBtn} ref={(input) => { this.submit = input }}>Submit</button></form>
    }

    addFieldset = (formSchema) => formSchema.map((fieldset) => {
        const elements = form[fieldset]
        return (fieldset.length > 0 && <fieldset>
            <legend>{fieldset}:</legend>
            {this.addFormElement(elements)}
        </fieldset>)
    })

    addFormElement = (elements) => elements.map((element) => {
        switch (element.type) {
            case "checkbox":
                return (<div>
                    <input type={element.type} id={element.id} onChange={this.onChangeHandler} /><label>{element.label}</label></div>)
            case "select":
                let disabledSelectBox = element.id === "state" ? this.state.disabledSelectBox : null
                return (<div><label>{element.label}:</label><div className="tooltip"><select id={element.id} disabled={disabledSelectBox} onChange={this.onChangeHandler} value={this.state[`${element.id}`]}>
                    <option value="" >Please Choose...</option>
                    {element.sourceList.length > 0 &&
                        this.populateSelectBox(element.sourceList)}
                </select><span className="tooltiptext">{element.definition}</span></div></div>)
            case "number":
                let numberRegex = (element.mask) ? `${element.mask}` : null
                return (<div><label>{element.label}:</label>
                    <div className="tooltip"><input type={element.type} id={element.id} onChange={this.onChangeHandler} data-mask={numberRegex} value={this.state[`${element.id}`]} /><span className="tooltiptext">{element.definition}</span></div></div >)
            default:
                let nameRegex = (element.mask) ? `${element.mask}` : null
                let disabledInput = null
                if (element.id === "middleName") {
                    disabledInput = this.state.disabledMiddleNameInput
                }
                else if (element.id === "address2") {
                    disabledInput = this.state.disabledapartmentOrSuiteInput
                }
                return (<div><label>{element.label}:</label>
                    <div className="tooltip"><input type={element.type} id={element.id} onChange={this.onChangeHandler} data-mask={nameRegex} value={this.state[`${element.id}`]} disabled={disabledInput} /><span className="tooltiptext">{element.definition}</span></div></div>)
        }
    })

    populateSelectBox = (sourceList) => sourceList.map((item) => {
        const name = item.name ? item.name : item
        return (
            <option value={name}>{name}</option>
        )
    })

    onChangeHandler = (e) => {
        const element = e.target.id
        const selector = document.getElementById(element)
        switch (element) {
            case "firstName":
            case "lastName":
            case "zipCode":
                this.setState({ [element]: e.target.value }, () => {
                    if (this.validateMask(e.target.value, e.target.attributes[2].value)) {
                        selector.style.outlineColor = "#000"
                        this.toggleSubmitBtn()
                    }
                    else {
                        selector.style.outlineColor = "#FF0000"
                    }
                })
                break;
            case "address1":
                this.setState({ [element]: e.target.value }, () => this.toggleSubmitBtn())
                break;
            case "hasMiddleName":
                this.setState({ [element]: e.currentTarget.checked }, () => this.toggleCheckBox("hasMiddleName", "middleName", "disabledMiddleNameInput"))
                break;
            case "middleName":
            case "address2":
                this.setState({ [element]: e.target.value })
                break;
            case "city":
                this.setState({ [element]: e.target.value }, () => this.toggleSelectBox())
                break;
            case "apartmentOrSuite":
                this.setState({ [element]: e.currentTarget.checked }, () => this.toggleCheckBox("apartmentOrSuite", "address2", "disabledapartmentOrSuiteInput"))
                break;
            case "state":
            case "country":
                this.setState({ [element]: selector.value }, () => this.toggleSubmitBtn())
                break;
            default:
                break;
        }
    }

    validateMask = (str, rEx) => {
        let regex = new RegExp(rEx.slice(1, -1));
        if (regex.test(str)) {
            return true
        } else {
            return false
        }
    }

    toggleCheckBox = (isChecked, input, disabledInput) => {
        if (this.state[isChecked] === true) {
            this.setState({ [input]: "", [disabledInput]: false })
        }
        else if (this.state[isChecked] === false) {
            this.setState({ [input]: "", [disabledInput]: true })
        }
    }

    toggleSelectBox = () => {
        if (this.state.city.length !== "") {
            this.setState({ disabledSelectBox: false })
        }
        else if (this.state.city.length === "") {
            this.setState({ disabledSelectBox: true })
        }
    }

    toggleSubmitBtn = () => {
        const submitBtn = this.submit;
        if (this.state.firstName != "" && this.state.lastName != "" && this.state.address1 != "" && this.state.state != "" && this.state.country != "" && this.state.zipCode != "") {
            this.setState({ disabledBtn: false });
            submitBtn.classList.remove("disabledBtn");
        }
        else if (this.state.firstName == "" || this.state.lastName == "" || this.state.address1 == "" || this.state.state == "" || this.state.country == "" || this.state.zipCode == "") {
            this.setState({ disabledBtn: true });
            submitBtn.classList.add("disabledBtn");
        }
    }

    resetForm = () => {
        this.setState(this.baseState)
    }

    onFormSubmitHandler = (e) => {
        e.preventDefault()
        const { firstName, middleName, lastName, address1, address2, city, state, country, zipCode } = this.state
        let user = {
            firstName,
            middleName,
            lastName,
            address1,
            address2,
            city,
            state,
            country,
            zipCode
        }
        alert(JSON.stringify(user))
        this.resetForm()
    }

}

export default Form;
